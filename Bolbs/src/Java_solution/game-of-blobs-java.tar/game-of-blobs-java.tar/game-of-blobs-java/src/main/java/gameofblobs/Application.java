package gameofblobs;

import com.google.common.collect.*;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Optional;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

public final class Application {

    private static double distance(Location a, Location b) {
        return sqrt(pow(a.getX() - b.getX(), 2.0) + pow(a.getY() - b.getY(), 2.0));
    }

    static Optional<Blob> locatePrey(Blob blob, List<Blob> blobs) {
        final Comparator<Blob> byDistance =
                Comparator.comparing(x -> distance(blob.getLocation(), x.getLocation()));

        return blobs.stream()
                .filter(x -> !blob.equals(x))
                .filter(x -> blob.getSize() > x.getSize())
                .min(byDistance);
    }

    private static int moveOneStepTowards(int blobCoordinate, int preyCoordinate) {
        if (blobCoordinate > preyCoordinate) return blobCoordinate - 1;
        else if (blobCoordinate < preyCoordinate) return blobCoordinate + 1;
        else return blobCoordinate;
    }

    static Blob moveTowards(Blob blob, Blob prey) {
        final Location blobLocation = blob.getLocation();
        final Location preyLocation = prey.getLocation();

        final Location newLocation = new Location(
                moveOneStepTowards(blobLocation.getX(), preyLocation.getX()),
                moveOneStepTowards(blobLocation.getY(), preyLocation.getY())
        );

        return new Blob(newLocation, blob.getSize());
    }

    static List<Blob> mergeBlobs(List<Blob> blobs) {
        final ImmutableListMultimap<Location, Blob> blobsByLocation = Multimaps.index(blobs, Blob::getLocation);

        return blobsByLocation.asMap().entrySet().stream()
                .map(entry -> new Blob(entry.getKey(), entry.getValue().stream().mapToInt(Blob::getSize).sum()))
                .collect(Collectors.toList());
    }

    static World updateState(World world) {
        final Function<Blob, Blob> locateAndMoveTowardsPrey = blob -> {
            final Optional<Blob> prey = locatePrey(blob, world.getBlobs());
            return prey.isPresent() ? moveTowards(blob, prey.get()) : blob;
        };

        final List<Blob> newBlobs = world.getBlobs().stream()
                .map(locateAndMoveTowardsPrey)
                .collect(Collectors.toList());

        return new World(world.getWidth(),
                world.getHeight(),
                mergeBlobs(newBlobs));
    }

    public static void main(String[] args) throws Exception {
        final List<Blob> blobs = Lists.newArrayList(
                new Blob(new Location(0, 2), 1),
                new Blob(new Location(2, 1), 2));
        final World world = new World(3, 3, blobs);

        final PeekingIterator<World> states =
                Iterators.peekingIterator(Stream.iterate(world, w -> updateState(w)).iterator());

        World currentState = states.next();
        while (states.hasNext() && !states.peek().equals(currentState)) {
            System.out.println(WorldDisplay.asString(currentState));
            currentState = states.next();
            System.out.println();
        }
        System.out.println(WorldDisplay.asString(currentState));
        System.out.println();

        System.out.println("Done");
    }
}
