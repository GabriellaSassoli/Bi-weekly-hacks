package gameofblobs;

import java.util.Objects;

public class Blob {
    private final Location location;
    private final int size;

    public Blob(Location location, int size) {
        this.location = location;
        this.size = size;
    }

    public Location getLocation() {
        return location;
    }

    public int getSize() {
        return size;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Blob blob = (Blob) o;
        return size == blob.size &&
                Objects.equals(location, blob.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(location, size);
    }

    @Override
    public String toString() {
        return "Blob{" +
                "location=" + location +
                ", size=" + size +
                '}';
    }
}
