package gameofblobs;

import java.util.List;
import java.util.Objects;

public class World {

    private final int width;
    private final int height;
    private final List<Blob> blobs;

    public World(int width, int height, List<Blob> blobs) {
        this.width = width;
        this.height = height;
        this.blobs = blobs;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public List<Blob> getBlobs() {
        return blobs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        World world = (World) o;
        return width == world.width &&
                height == world.height &&
                (blobs.containsAll(world.blobs) && world.blobs.containsAll(blobs));
    }

    @Override
    public int hashCode() {
        return Objects.hash(width, height, blobs);
    }

    @Override
    public String toString() {
        return "World{" +
                "width=" + width +
                ", height=" + height +
                ", blobs=" + blobs +
                '}';
    }
}
