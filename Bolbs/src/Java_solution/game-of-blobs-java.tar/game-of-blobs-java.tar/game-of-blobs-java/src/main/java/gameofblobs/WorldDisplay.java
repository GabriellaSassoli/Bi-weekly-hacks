package gameofblobs;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class WorldDisplay {

    public static String asString(World world) {
        final Map<Location, Blob> blobsByLocation = Maps.uniqueIndex(world.getBlobs(), Blob::getLocation);
        final String asString =
                IntStream.range(0, world.getHeight()).boxed().map(y ->
                        IntStream.range(0, world.getWidth()).boxed().map(x -> {
                            final Location location = new Location(x, y);
                            if (blobsByLocation.containsKey(location)) {
                                return String.valueOf(blobsByLocation.get(location).getSize());
                            } else {
                                return ".";
                            }
                        }).collect(Collectors.joining()) + "\n"
                ).collect(Collectors.joining());
        return asString;
    }
}
