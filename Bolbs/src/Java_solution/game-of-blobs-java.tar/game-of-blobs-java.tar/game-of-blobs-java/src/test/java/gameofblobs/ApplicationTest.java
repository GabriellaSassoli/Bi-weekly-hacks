package gameofblobs;

import com.google.common.collect.Lists;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static testcommon.TestUtils.createBlob;

public class ApplicationTest {


    @Test
    public void locatePreyGivenNoPreyExistsThenNone() {
        // Given
        final List<Blob> blobs = Lists.newArrayList(
                createBlob(1, 1, 1),
                createBlob(2, 2, 2));

        // When
        final Optional<Blob> actual = Application.locatePrey(blobs.get(0), Lists.newArrayList(blobs));

        // Then
        assertThat(actual).isEmpty();
    }

    @Test
    public void locatePreyGivenPreyExistsThenClosestPrey() {
        // Given
        final List<Blob> blobs = Lists.newArrayList(
                createBlob(1, 1, 1),
                createBlob(2, 2, 2),
                createBlob(3, 3, 3));

        // When
        final Optional<Blob> actual = Application.locatePrey(blobs.get(2), Lists.newArrayList(blobs));

        // Then
        assertThat(actual).contains(blobs.get(1));
    }

    @Test
    public void moveTowardsGivenPreyLocationGreaterThanBlobLocationThenIncreasesLocation() {
        // Given, When
        final Blob actual = Application.moveTowards(createBlob(1, 1, 1), (createBlob(3, 3, 1)));

        // Then
        final Blob expected = createBlob(2, 2, 1);
        assertThat(actual.getLocation()).isEqualTo(expected.getLocation());
        assertThat(actual.getSize()).isEqualTo(expected.getSize());
    }

    @Test
    public void moveTowardsGivenPreyLocationLessThanBlobLocationThenIncreasesLocation() {
        // Given, When
        final Blob actual = Application.moveTowards(createBlob(2, 2, 1), createBlob(2, 2, 1));

        // Then
        final Blob expected = createBlob(2, 2, 1);
        assertThat(actual.getLocation()).isEqualTo(expected.getLocation());
        assertThat(actual.getSize()).isEqualTo(expected.getSize());
    }

    @Test
    public void moveTowardsGivenPreyLocationEqualToBlobLocationThenDoesNotMove() {
        // Given, When
        final Blob actual = Application.moveTowards(createBlob(2, 2, 1), createBlob(2, 2, 1));

        // Then
        final Blob expected = createBlob(2, 2, 1);
        assertThat(actual.getLocation()).isEqualTo(expected.getLocation());
        assertThat(actual.getSize()).isEqualTo(expected.getSize());
    }

}
