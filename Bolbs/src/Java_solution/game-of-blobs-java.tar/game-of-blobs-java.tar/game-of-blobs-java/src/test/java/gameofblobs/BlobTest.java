package gameofblobs;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static testcommon.EqualityAndHashCodeTester.testEqualityAndHashCode;

public class BlobTest {

    private static final List<Blob> equalBlobs = Arrays.asList(
            new Blob(new Location(1, 2), 3),
            new Blob(new Location(1, 2), 3));

    private static final List<Blob> differentBlobs = Arrays.asList(
            new Blob(new Location(1, 2), 3),
            new Blob(new Location(1, 1), 3),
            new Blob(new Location(2, 2), 3),
            new Blob(new Location(1, 2), 4));

    @Test
    public void satisfiesEqualityAndHashCodeContracts() {
        testEqualityAndHashCode(equalBlobs, differentBlobs);
    }
}
