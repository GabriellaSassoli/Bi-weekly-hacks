package gameofblobs;


import com.google.common.collect.Sets;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static testcommon.EqualityAndHashCodeTester.testEqualityAndHashCode;
import static testcommon.TestUtils.createBlob;
import static testcommon.TestUtils.createWorld;

public class WorldTest {

    private static final List<Blob> blobsOne = Lists.newArrayList(
            createBlob(1, 1, 1),
            createBlob(2, 2, 2),
            createBlob(3, 3, 3));

    private static final List<Blob> blobsTwo = Lists.newArrayList(
            createBlob(2, 2, 2),
            createBlob(3, 3, 3),
            createBlob(4, 4, 4));

    private static final List<World> equalWorlds = Arrays.asList(
            createWorld(5, 10, Lists.newArrayList(blobsOne)),
            createWorld(5, 10, Lists.newArrayList(blobsOne)));

    private static final List<World> differentWorlds = Arrays.asList(
            createWorld(5, 10, Lists.newArrayList(blobsOne)),
            createWorld(1, 10, Lists.newArrayList(blobsOne)),
            createWorld(5, 10, Lists.newArrayList(blobsTwo)));

    @Test
    public void satisfiesEqualityAndHashCodeContracts() {
        testEqualityAndHashCode(equalWorlds, differentWorlds);
    }
}
